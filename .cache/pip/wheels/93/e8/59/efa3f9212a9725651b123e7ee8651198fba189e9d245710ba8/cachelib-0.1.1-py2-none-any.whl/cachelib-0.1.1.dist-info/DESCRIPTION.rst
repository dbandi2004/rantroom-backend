cachelib
========

A collection of cache libraries in the same API interface. Extracted from
werkzeug.


Installing
----------

Install and update using pip::

    pip install -U cachelib


Authors & License
-----------------

Maintained by Pallets Team, licensed under BSD.


